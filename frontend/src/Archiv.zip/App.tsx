// src/App.tsx
import { useEffect, useMemo, useState } from "react";
import Sidebar from "./components/Sidebar";
import FileItem from "./components/FileItem";
import DetailModal from "./components/DetailModal";
import type { EmailWithResponse } from "./types";
import TopBar from "./components/TopBar";
import HeaderActions from "./components/HeaderActions";

// --- 1) Kategorien-Tabs (Sidebar)
type TabKey = "client-request" | "order" | "invoice";

// --- 2) Status-Tabs (TopBar)  — muss zu deiner TopBar.tsx passen
type StatusTab = "inbox" | "bearbeitet" | "in_bearbeitung" | "action_required";

const mapKategorieToTab = (k: EmailWithResponse["Kategorie"]): TabKey => {
  switch (k) {
    case "Kundenanfrage":
      return "client-request";
    case "Bestellung":
      return "order";
    case "Rechnung":
      return "invoice";
    default:
      return "order"; // Fallback
  }
};

export default function App() {
  const [emails, setEmails] = useState<EmailWithResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<EmailWithResponse | null>(null);

  // Sidebar (Kategorie)
  const [activeTab, setActiveTab] = useState<TabKey>("client-request");
  // TopBar (Status)
  const [statusTab, setStatusTab] = useState<StatusTab>("inbox");

  useEffect(() => {
    const fetchEmails = async () => {
      try {
        const res = await fetch("http://localhost:8001/emails");
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setEmails(data as EmailWithResponse[]);
      } catch (e: any) {
        setError(e.message || "Fehler beim Laden");
      } finally {
        setLoading(false);
      }
    };
    fetchEmails();
  }, []);

  // Zuerst: Counts für die Sidebar-Kategorien
  const counts = useMemo(() => {
    const base: Record<TabKey, number> = {
      "client-request": 0,
      order: 0,
      invoice: 0,
    };
    for (const mail of emails) {
      const key = mapKategorieToTab(mail.Kategorie);
      base[key] += 1;
    }
    return base;
  }, [emails]);

  // 1. Filter: nach Kategorie (Sidebar)
  const filteredByCategory = useMemo(
    () => emails.filter((m) => mapKategorieToTab(m.Kategorie) === activeTab),
    [emails, activeTab]
  );

  // Optional: Status-Badges in der TopBar (Counts je Status – innerhalb der gewählten Kategorie)
  const statusCounts = useMemo(() => {
    return {
      inbox: filteredByCategory.length, // „Inbox = alle“ (wie von dir gewünscht)
      bearbeitet: filteredByCategory.filter((e) => e.status === "bearbeitet").length,
      in_bearbeitung: filteredByCategory.filter((e) => e.status === "in_bearbeitung").length,
      action_required: filteredByCategory.filter((e) => e.status === "action_required").length,
    };
  }, [filteredByCategory]);

  // 2. Filter: nach Status (TopBar)
  const filtered = useMemo(() => {
    if (statusTab === "inbox") return filteredByCategory; // „Inbox = alle gelistet“
    return filteredByCategory.filter((m) => m.status === statusTab);
  }, [filteredByCategory, statusTab]);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Linke Kategorie-Navigation */}
      <Sidebar active={activeTab} counts={counts} onChange={setActiveTab} />

      <div className="flex flex-col flex-1">
        <main className="flex-1 p-6 overflow-y-auto">
          {/* Kopfzeile */}
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold text-gray-800">
              {activeTab === "client-request"
                ? "Client Requests"
                : activeTab === "order"
                ? "Orders"
                : "Invoices"}
            </h1>
            <HeaderActions />
          </div>

          {/* Status-TopBar (filtert innerhalb der gewählten Kategorie) */}
          <TopBar
            activeTab={statusTab}       // ← StatusTab!
            onChange={setStatusTab}      // Achte darauf: TopBar-Prop heißt onChange (nicht setActiveTab)
            counts={statusCounts}
          />

          {/* Tabelle */}
          <div className="bg-gray-100 rounded-md overflow-hidden shadow-sm">
            <div className="grid grid-cols-[minmax(0,1fr)_300px_200px_40px] text-sm font-medium text-gray-500 bg-gray-200 py-2 px-4">
              <span>File</span>
              <span>Status</span>
              <span>Received at</span>
              <span></span>
            </div>

            {loading && (
              <div className="p-4 text-center text-gray-600">Lade E-Mails…</div>
            )}
            {error && (
              <div className="p-4 text-center text-red-600">Fehler: {error}</div>
            )}
            {!loading && !error && filtered.length === 0 && (
              <div className="p-4 text-center text-gray-600">
                Keine Einträge in dieser Kategorie / diesem Status.
              </div>
            )}

            {!loading &&
              filtered.map((email) => (
                <FileItem
                  key={email.id}
                  email={email}
                  selected={selected?.id === email.id}
                  onClick={() => setSelected(email)}
                  compact
                />
              ))}
          </div>
        </main>

        {selected && (
          <DetailModal email={selected} onClose={() => setSelected(null)} />
        )}
      </div>
    </div>
  );
}
